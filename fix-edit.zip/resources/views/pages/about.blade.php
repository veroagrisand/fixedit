@extends('layout.template')

@section('title', 'About')

@section('content')
    <h1>Ini About</h1>

    <!--  -->
    
@stop