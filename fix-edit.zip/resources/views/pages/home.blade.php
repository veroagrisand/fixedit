@extends('layout.template')

@section('title', 'Home')

@section('content')
    <h1>Ini Home</h1>
    
@stop